class Punto:
    def __init__(self, id: int, nombre: str, feature: dict):
        self.id = id
        self.nombre = nombre
        self.feature = feature