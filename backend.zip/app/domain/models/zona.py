class Zona:
    def __init__(self, id: int, nombre: str, tipo: str, feature: dict):
        self.id = id
        self.nombre = nombre
        self.tipo = tipo
        self.feature = feature