from app.core.config import database

async def get_db():
    return database

